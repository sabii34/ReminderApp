
package com.reminderapp.geofence

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderAlarmScheduler {
  private fun pending(
    context: Context,
    reminder: GeofenceReminder
  ): PendingIntent =
    PendingIntent.getBroadcast(
      context,
      reminder.id.hashCode(),
      Intent(context, ReminderScheduledReceiver::class.java)
        .putExtra("reminderId", reminder.id),
      PendingIntent.FLAG_UPDATE_CURRENT or
        PendingIntent.FLAG_IMMUTABLE,
    )

  fun sync(
    context: Context,
    reminders: List<GeofenceReminder>
  ) {
    val manager =
      context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    reminders.forEach { reminder ->
      val pi = pending(context, reminder)

      if (reminder.remindAt > System.currentTimeMillis()) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          manager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            reminder.remindAt,
            pi,
          )
        } else {
          manager.set(
            AlarmManager.RTC_WAKEUP,
            reminder.remindAt,
            pi,
          )
        }
      } else {
        manager.cancel(pi)
      }
    }
  }

  fun cancel(
    context: Context,
    reminder: GeofenceReminder
  ) {
    val manager =
      context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    manager.cancel(pending(context, reminder))
  }
}
